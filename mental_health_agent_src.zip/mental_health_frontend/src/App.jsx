import { useState, useRef, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Send, Heart, MessageCircle, Phone, AlertTriangle } from 'lucide-react'
import './App.css'

function App() {
  const [messages, setMessages] = useState([
    {
      sender: 'agent',
      message: "Hello! I'm your mental health assistant. I'm here to listen and support you. How are you feeling today?",
      timestamp: new Date().toISOString()
    }
  ])
  const [inputMessage, setInputMessage] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [sessionId, setSessionId] = useState(null)
  const [showResources, setShowResources] = useState(false)
  const [resources, setResources] = useState([])
  const messagesEndRef = useRef(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    // Generate a session ID when the component mounts
    setSessionId(Date.now().toString())
  }, [])

  const sendMessage = async () => {
    if (!inputMessage.trim() || isLoading) return

    const userMessage = {
      sender: 'user',
      message: inputMessage,
      timestamp: new Date().toISOString()
    }

    setMessages(prev => [...prev, userMessage])
    setInputMessage('')
    setIsLoading(true)

    try {
      const response = await fetch('http://localhost:5000/api/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          message: inputMessage,
          session_id: sessionId,
          user_id: 'demo_user'
        })
      })

      const data = await response.json()

      if (response.ok) {
        const agentMessage = {
          sender: 'agent',
          message: data.agent_response,
          timestamp: new Date().toISOString(),
          intent: data.intent,
          sentiment: data.sentiment,
          resources: data.resources
        }

        setMessages(prev => [...prev, agentMessage])

        // Show crisis resources if needed
        if (data.action_required === 'crisis_escalation' && data.resources) {
          setResources(data.resources)
          setShowResources(true)
        }
      } else {
        throw new Error(data.error || 'Failed to send message')
      }
    } catch (error) {
      console.error('Error sending message:', error)
      const errorMessage = {
        sender: 'agent',
        message: "I'm sorry, I'm having trouble responding right now. Please try again in a moment.",
        timestamp: new Date().toISOString()
      }
      setMessages(prev => [...prev, errorMessage])
    } finally {
      setIsLoading(false)
    }
  }

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage()
    }
  }

  const getSentimentColor = (sentiment) => {
    switch (sentiment) {
      case 'positive': return 'bg-green-100 text-green-800'
      case 'negative': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getIntentIcon = (intent) => {
    switch (intent) {
      case 'crisis': return <AlertTriangle className="w-4 h-4" />
      case 'anxiety': return <Heart className="w-4 h-4" />
      case 'depression': return <MessageCircle className="w-4 h-4" />
      default: return <MessageCircle className="w-4 h-4" />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <Card className="mb-6">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl font-bold text-gray-800 flex items-center justify-center gap-2">
              <Heart className="w-6 h-6 text-red-500" />
              Mental Health Assistant
            </CardTitle>
            <p className="text-gray-600">AI-powered support for your mental well-being</p>
          </CardHeader>
        </Card>

        {/* Crisis Resources Alert */}
        {showResources && (
          <Alert className="mb-6 border-red-200 bg-red-50">
            <AlertTriangle className="h-4 w-4 text-red-600" />
            <AlertDescription>
              <div className="font-semibold text-red-800 mb-2">Crisis Support Resources:</div>
              {resources.map((resource, index) => (
                <div key={index} className="mb-1">
                  <strong>{resource.name}:</strong> {resource.phone || resource.text}
                </div>
              ))}
              <Button 
                variant="outline" 
                size="sm" 
                className="mt-2"
                onClick={() => setShowResources(false)}
              >
                Close
              </Button>
            </AlertDescription>
          </Alert>
        )}

        {/* Chat Container */}
        <Card className="h-96 flex flex-col">
          <CardContent className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((message, index) => (
              <div
                key={index}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                    message.sender === 'user'
                      ? 'bg-blue-500 text-white'
                      : 'bg-white text-gray-800 border'
                  }`}
                >
                  <div className="whitespace-pre-wrap">{message.message}</div>
                  
                  {/* Show intent and sentiment for agent messages */}
                  {message.sender === 'agent' && (message.intent || message.sentiment) && (
                    <div className="flex gap-2 mt-2">
                      {message.intent && (
                        <Badge variant="outline" className="text-xs">
                          {getIntentIcon(message.intent)}
                          <span className="ml-1">{message.intent}</span>
                        </Badge>
                      )}
                      {message.sentiment && (
                        <Badge className={`text-xs ${getSentimentColor(message.sentiment)}`}>
                          {message.sentiment}
                        </Badge>
                      )}
                    </div>
                  )}
                  
                  <div className="text-xs opacity-70 mt-1">
                    {new Date(message.timestamp).toLocaleTimeString()}
                  </div>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-white text-gray-800 border px-4 py-2 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <div className="animate-pulse">Thinking...</div>
                  </div>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </CardContent>
          
          {/* Input Area */}
          <div className="border-t p-4">
            <div className="flex space-x-2">
              <Input
                value={inputMessage}
                onChange={(e) => setInputMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message here..."
                disabled={isLoading}
                className="flex-1"
              />
              <Button 
                onClick={sendMessage} 
                disabled={isLoading || !inputMessage.trim()}
                size="icon"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              This is an AI assistant. In case of emergency, please call 911 or contact a crisis helpline.
            </p>
          </div>
        </Card>

        {/* Quick Actions */}
        <Card className="mt-6">
          <CardContent className="p-4">
            <h3 className="font-semibold mb-3">Quick Actions</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <Button 
                variant="outline" 
                className="justify-start"
                onClick={() => setInputMessage("I'm feeling anxious")}
              >
                <Heart className="w-4 h-4 mr-2" />
                I'm feeling anxious
              </Button>
              <Button 
                variant="outline" 
                className="justify-start"
                onClick={() => setInputMessage("I need coping strategies")}
              >
                <MessageCircle className="w-4 h-4 mr-2" />
                Need coping strategies
              </Button>
              <Button 
                variant="outline" 
                className="justify-start"
                onClick={() => setInputMessage("Tell me about mental health resources")}
              >
                <Phone className="w-4 h-4 mr-2" />
                Find resources
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

export default App

